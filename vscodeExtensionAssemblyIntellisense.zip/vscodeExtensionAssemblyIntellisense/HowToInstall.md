## Cosa è
E' un pacchetto di Vscode Extension, derivato dall'estensione < ASM Code Lens - maziac >

Il fork è in https://github.com/iSlans/asm-code-lens

L'ho adattato al nostro uso a Reti logiche.  
Ho aggiunto:
+ Documentazione dei comandi assembler onhover
+ Snippets (Autocompletamento) dei registri, direttive e comandi

## Per installarlo
0. Essendo una copia quasi esatta dell'originale, per evitare conflitti penso dobbiate disinstallare l'originale "ASM Code Lens" di maziac

1. Aprire il terminale in questa cartella, dove c'è il .vsix

2. Eseguire 
```
code --install-extension asm-code-lens-1.10.2.vsix
```
3. Fine.


(se mai il nome del file non concidesse con quello che ho scritto su, bisogna ovviamente scrivere quello del file.)

### Documentazione onHover

Le documentazioni li ho scritti io in breve tempo, quindi magari fanno un po' schifo. Li potete modificare anche da voi. Si trovano in  
    
    {pathToExtension}/out/src/documentation.s

Se qualcuno vuole aiutare ben venga. 

### Snippets
Si dovrebbero attivare quando scrivete in file .s  

Potrebbe essere che si trovano in fondo alla lista dei suggerimenti mostrati. Basta spostarli in cima, nelle impostazioni settare

    editor.snippetSuggestions = top

Anche questi ovviamente potete modificarli da voi in

    {pathToExtension}/snippets.json
